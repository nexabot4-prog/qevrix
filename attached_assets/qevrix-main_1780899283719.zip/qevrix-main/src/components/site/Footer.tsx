import { Link } from "@tanstack/react-router";

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="mt-40 bg-background">
      <div className="container-q border-t border-border pt-16 pb-14">
        <div className="grid gap-12 md:grid-cols-3">
          {/* Left: brand + tagline + copyright */}
          <div className="space-y-5">
            <Link to="/" aria-label="QEVRIX Home" className="font-display text-2xl font-bold tracking-tight text-foreground inline-block">
              QEVRI<span style={{ color: "#FF6B00" }}>X</span>
              <span className="text-[color:var(--accent)]">.</span>
            </Link>
            <p className="text-[14px] leading-relaxed text-muted-foreground max-w-[28ch]">
              Engineering Support &amp; Innovation Systems
            </p>
            <p className="text-[14px] text-muted-foreground">
              © {year} QEVRIX. All rights reserved.
            </p>
            <p className="text-[12px]" style={{ color: "rgba(255,255,255,0.35)" }}>
              <Link to="/privacy" className="hover:text-foreground transition-colors">Privacy Policy</Link>
              <span className="mx-2">·</span>
              <Link to="/terms" className="hover:text-foreground transition-colors">Terms</Link>
              <span className="mx-2">·</span>
              <Link to="/sitemap" className="hover:text-foreground transition-colors">Sitemap</Link>
            </p>
          </div>

          {/* Center: navigation */}
          <nav className="flex flex-col gap-3 md:items-center md:pt-1">
            {[
              { to: "/", label: "Home" },
              { to: "/about", label: "About Us" },
              { to: "/projects", label: "Projects" },
              { to: "/contact", label: "Contact" },
            ].map((l) => (
              <Link
                key={l.to}
                to={l.to}
                className="text-[14px] text-muted-foreground hover:text-foreground transition-colors"
              >
                {l.label}
              </Link>
            ))}
          </nav>

          {/* Right: contact + social */}
          <div className="flex flex-col gap-3 md:items-end md:pt-1">
            <a href="mailto:hello@qevrix.com" className="text-[14px] text-muted-foreground hover:text-foreground transition-colors">
              hello@qevrix.com
            </a>
            <a href="https://instagram.com/qevrix" target="_blank" rel="noreferrer" aria-label="Instagram" className="text-[14px] text-muted-foreground hover:text-foreground transition-colors">
              Instagram
            </a>
            <a href="https://linkedin.com/company/qevrix" target="_blank" rel="noreferrer" aria-label="LinkedIn" className="text-[14px] text-muted-foreground hover:text-foreground transition-colors">
              LinkedIn
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}