import type { ReactNode } from "react";
import { Nav } from "./Nav";
import { Footer } from "./Footer";

export function SiteLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="page-frame" aria-hidden="true" />
      <Nav />
      <main role="main">{children}</main>
      <Footer />
    </div>
  );
}