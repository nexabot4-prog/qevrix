import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";

const links = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About Us" },
  { to: "/projects", label: "Projects" },
  { to: "/contact", label: "Contact" },
] as const;

export function Nav() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 bg-transparent ${
        open ? "bg-background/85 backdrop-blur-xl" : ""
      }`}
    >
      <div className="container-q flex h-16 md:h-20 items-center justify-between">
        <Link
          to="/"
          onClick={() => setOpen(false)}
          aria-label="QEVRIX Home"
          className="flex items-center font-display text-xl md:text-2xl font-bold tracking-tight text-foreground"
        >
          <img
            src="/qx-logo.png"
            alt="QEVRIX Logo"
            style={{ height: 32, width: "auto", objectFit: "contain" }}
          />
          <span style={{ marginLeft: 10 }}>
            QEVRI<span style={{ color: "#FF6B00" }}>X</span>
            <span className="text-[color:var(--accent)]">.</span>
          </span>
        </Link>

        <nav className="hidden md:flex items-center gap-10">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              activeOptions={{ exact: true }}
              aria-label={l.label}
              className="font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground hover:text-foreground transition-colors"
              activeProps={{ className: "font-mono text-[11px] uppercase tracking-[0.18em] text-foreground" }}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <button
          aria-label="Toggle menu"
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
          className="md:hidden relative h-10 w-10 flex flex-col items-center justify-center gap-1.5"
        >
          <span className={`block h-px w-6 bg-foreground transition-transform duration-300 ${open ? "translate-y-[3px] rotate-45" : ""}`} />
          <span className={`block h-px w-6 bg-foreground transition-transform duration-300 ${open ? "-translate-y-[3px] -rotate-45" : ""}`} />
        </button>
      </div>

      {/* Mobile sheet */}
      <div
        className={`md:hidden overflow-hidden transition-[max-height,opacity] duration-500 ease-out ${
          open ? "max-h-[80vh] opacity-100" : "max-h-0 opacity-0"
        }`}
      >
        <nav className="container-q flex flex-col gap-6 py-10">
          {links.map((l, i) => (
            <Link
              key={l.to}
              to={l.to}
              onClick={() => setOpen(false)}
              className="font-display text-4xl font-semibold text-foreground"
              style={{ transitionDelay: `${i * 60}ms` }}
            >
              {l.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}