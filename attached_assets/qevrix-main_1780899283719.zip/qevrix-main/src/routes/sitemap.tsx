import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/Layout";
import { PillTags } from "@/components/site/PillTags";

export const Route = createFileRoute("/sitemap")({
  head: () => ({
    meta: [
      { title: "Sitemap — QEVRIX" },
      { name: "description", content: "All pages on the QEVRIX website." },
      { property: "og:title", content: "Sitemap — QEVRIX" },
      { property: "og:description", content: "All pages on the QEVRIX website." },
    ],
  }),
  component: Sitemap,
});

const pages = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About Us" },
  { to: "/projects", label: "Projects" },
  { to: "/contact", label: "Contact" },
  { to: "/privacy", label: "Privacy Policy" },
  { to: "/terms", label: "Terms of Service" },
] as const;

function Sitemap() {
  return (
    <SiteLayout>
      <section className="pt-40 md:pt-56 pb-24">
        <div className="container-q max-w-4xl">
          <PillTags filled="Index" outline="Sitemap" className="mb-10" />
          <h1 className="text-display-hero">Sitemap<span className="text-[color:var(--accent)]">.</span></h1>
        </div>
      </section>
      <section className="pb-40">
        <ul className="container-q max-w-3xl divide-y divide-border border-y border-border">
          {pages.map((p) => (
            <li key={p.to}>
              <Link to={p.to} className="flex items-center justify-between py-6 group">
                <span className="font-display text-2xl md:text-3xl font-semibold group-hover:text-[color:var(--accent)] transition-colors">
                  {p.label}
                </span>
                <span className="font-mono uppercase text-muted-foreground" style={{ fontSize: 11, letterSpacing: "0.18em" }}>
                  {p.to}
                </span>
              </Link>
            </li>
          ))}
        </ul>
      </section>
    </SiteLayout>
  );
}