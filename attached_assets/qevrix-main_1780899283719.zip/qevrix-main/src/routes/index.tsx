import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/Layout";
import { Reveal } from "@/components/site/Reveal";
import { PillTags } from "@/components/site/PillTags";
import { CountUp } from "@/components/site/CountUp";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "QEVRIX — Engineering Beyond Submission" },
      { name: "description", content: "QEVRIX is an emerging engineering ecosystem building systems across robotics, automation, embedded systems, AI and future software platforms." },
      { property: "og:title", content: "QEVRIX — Engineering Beyond Submission" },
      { property: "og:description", content: "Building systems, enabling innovation, and shaping the future of engineering." },
    ],
  }),
  component: Home,
});

const domains = [
  { n: "01", k: "Robotics", d: "Autonomous mechanical systems engineered for precision in motion, perception, and coordinated action." },
  { n: "02", k: "Automation", d: "Industrial and process automation that compresses time, removes friction, and scales human capability." },
  { n: "03", k: "Embedded Systems", d: "Low-level firmware and hardware integration designed for reliability at the edge of compute." },
  { n: "04", k: "AI Systems", d: "Applied intelligence woven into infrastructure — models, agents, and decision systems built for production." },
  { n: "05", k: "Software Platforms", d: "Foundational platforms that engineers, operators and machines build on top of." },
];

const future = [
  { phase: "2025 / Today", title: "Engineering Support", body: "Working alongside engineers to ship real, deployable systems — the first chapter." },
  { phase: "Next", title: "Innovation Labs", body: "Dedicated research surfaces where new architectures, prototypes and platforms take shape." },
  { phase: "Next", title: "Automation Systems", body: "Productized automation deployed inside operations, factories and digital infrastructure." },
  { phase: "Next", title: "R&D", body: "Long-horizon work on the primitives that future engineering teams will depend on." },
  { phase: "Horizon", title: "Technology Products", body: "Owned products that carry the QEVRIX standard of engineering into the market." },
  { phase: "Horizon", title: "Future Platforms", body: "Platforms that don't yet exist — built for the engineering disciplines of the next decade." },
];

const work = [
  { tag: "Robotics & Automation · 2026", title: "Autonomous Delivery Robot", desc: "A reusable autonomy layer combining perception, control and safety primitives for ground robotics." },
  { tag: "EV & Energy · 2026", title: "Smart EV Charging Platform", desc: "A connected charging infrastructure delivering secure access, intelligent power allocation, and real-time station management." },
  { tag: "AI Vision · 2026", title: "VisionGuard", desc: "An AI-powered surveillance platform for intelligent monitoring, anomaly detection, and real-time visual analysis." },
];

const testimonials = [
  {
    quote: "QEVRIX builds with the kind of intent you rarely see at the student level. Their work feels production-grade.",
    name: "Placeholder Name",
    role: "Faculty Mentor",
  },
  {
    quote: "Their autonomous platform was the most thoughtfully engineered project we reviewed this year.",
    name: "Placeholder Name",
    role: "Industry Reviewer",
  },
  {
    quote: "A team that treats engineering as a craft, not a checklist. Looking forward to what they build next.",
    name: "Placeholder Name",
    role: "Innovation Partner",
  },
];

function Home() {
  return (
    <SiteLayout>
      {/* HERO */}
      <section className="relative min-h-[100svh] flex flex-col items-center justify-center text-center px-6 pt-32 pb-24 overflow-hidden">
        <div className="container-q flex flex-col items-center">
          <Reveal>
            <PillTags filled="QEVRIX" outline="Engineering Ecosystem" className="justify-center mb-10" />
          </Reveal>
          <h1 className="text-display-hero max-w-[14ch]">
            <Reveal as="span" className="block">Engineering Beyond</Reveal>
            <Reveal as="span" delay={160} className="block">
              Submission<span className="text-[color:var(--accent)]">.</span>
            </Reveal>
          </h1>
          <Reveal delay={360}>
            <p className="mt-10 max-w-xl mx-auto text-base md:text-lg text-muted-foreground leading-relaxed">
              Building systems, enabling innovation, and shaping the future of engineering.
            </p>
          </Reveal>
          <Reveal delay={500}>
            <div className="mt-12 flex flex-wrap items-center justify-center gap-4">
              <Link to="/projects" className="btn-pill btn-pill-primary">View Work</Link>
              <Link to="/about" className="btn-pill btn-pill-secondary">Inside QEVRIX</Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* THE GAP */}
      <section className="py-40 md:py-64">
        <div className="container-q max-w-5xl mx-auto">
          <Reveal>
            <PillTags filled="01" outline="The Gap" className="mb-10" />
          </Reveal>
          <Reveal>
            <h2 className="text-display-xl">
              Engineering education teaches <span className="text-muted-foreground">concepts.</span>
            </h2>
          </Reveal>
          <Reveal delay={160}>
            <h2 className="text-display-xl mt-6">
              Real engineering demands <span className="text-[color:var(--accent)]">execution.</span>
            </h2>
          </Reveal>
        </div>
      </section>

      {/* WHY QEVRIX EXISTS */}
      <section className="py-32 md:py-48">
        <div className="container-q">
          <Reveal>
            <PillTags filled="02" outline="Why QEVRIX Exists" className="mb-16" />
          </Reveal>
          <div className="grid md:grid-cols-12 gap-12 items-start">
            <Reveal className="md:col-span-7">
              <h2 className="text-display-xl">
                A bridge between <em className="not-italic text-muted-foreground">what is taught</em> and what gets <span className="text-foreground">built</span>.
              </h2>
            </Reveal>
            <Reveal delay={160} className="md:col-span-5 md:pt-10 space-y-6">
              <p className="text-muted-foreground leading-relaxed">
                QEVRIX is not an agency, a coaching institute, or a service shop. It is an engineering ecosystem built around a single conviction — that the next generation of engineers must learn by building real systems, not by submitting another assignment.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Our mission is to bridge learning and building, and to grow — quietly, deliberately — into a company that defines the engineering standard of its decade.
              </p>
            </Reveal>
          </div>
        </div>
      </section>

      {/* ENGINEERING DOMAINS */}
      <section className="py-32 md:py-48">
        <div className="container-q mb-20">
          <Reveal>
            <PillTags filled="03" outline="Engineering Domains" className="mb-6" />
            <h2 className="text-display-xl max-w-3xl">Five disciplines. One engineering standard.</h2>
          </Reveal>
        </div>

        <ul className="container-q flex flex-col gap-12 md:gap-16">
          {domains.map((d, i) => (
            <li key={d.n}>
              <Reveal delay={i * 80}>
                <div className="grid md:grid-cols-12 gap-6">
                  <span className="md:col-span-2 font-mono text-xs text-muted-foreground pt-3">{d.n}</span>
                  <h3 className="md:col-span-5 font-display text-3xl md:text-5xl font-semibold tracking-tight">
                    {d.k}
                  </h3>
                  <p className="md:col-span-5 text-muted-foreground leading-relaxed md:pt-3">{d.d}</p>
                </div>
              </Reveal>
            </li>
          ))}
        </ul>
      </section>

      {/* STATS — BY THE NUMBERS */}
      <section
        className="py-32 md:py-44"
        style={{
          borderTop: "1px solid rgba(255,255,255,0.06)",
          borderBottom: "1px solid rgba(255,255,255,0.06)",
        }}
      >
        <div className="container-q">
          <Reveal>
            <PillTags filled="05" outline="By The Numbers" className="mb-16" />
          </Reveal>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-12 md:gap-8">
            {[
              { num: 5, suffix: "+", label: "Systems Built" },
              { num: 5, suffix: "", label: "Engineering Domains" },
              { num: 2026, suffix: "", label: "Founded" },
              { text: "India · Remote", label: "Based" },
            ].map((s, i) => (
              <Reveal key={i} delay={i * 80}>
                <div>
                  <div className="font-display font-bold text-foreground tracking-tight" style={{ fontSize: "clamp(2.5rem, 5vw, 4rem)", lineHeight: 1 }}>
                    {"text" in s ? s.text : <CountUp end={s.num!} suffix={s.suffix} />}
                  </div>
                  <p className="mt-4 font-mono uppercase" style={{ color: "#FF6B00", fontSize: 11, letterSpacing: "0.1em" }}>
                    {s.label}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* FUTURE VISION */}
      <section className="relative py-40 md:py-64 overflow-hidden">
        {/* Subtle radial orange glow */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0"
          style={{
            background:
              "radial-gradient(60% 50% at 50% 50%, rgba(255,107,0,0.14), transparent 70%)",
          }}
        />
        <div className="container-q relative text-center">
          <Reveal>
            <PillTags filled="06" outline="Future Vision" className="justify-center mb-12" />
          </Reveal>
          <Reveal>
            <h2 className="text-display-hero max-w-[18ch] mx-auto">
              Today an ecosystem.{" "}
              <span className="text-muted-foreground">Tomorrow,</span> a company building the future of engineering.
            </h2>
          </Reveal>
          <Reveal delay={240}>
            <p className="mt-10 max-w-2xl mx-auto text-muted-foreground leading-relaxed">
              Today: Engineering Support. Tomorrow: Innovation Labs · Automation Systems · R&amp;D · Technology Products · Future Platforms.
            </p>
          </Reveal>
        </div>
      </section>

      {/* SELECTED WORK */}
      <section className="py-32 md:py-48">
        <div className="container-q mb-20 flex items-end justify-between gap-8 flex-wrap">
          <Reveal>
            <PillTags filled="07" outline="Selected Work" className="mb-6" />
            <h2 className="text-display-xl">A small body of work. Built with intent.</h2>
          </Reveal>
          <Reveal delay={120}>
            <Link to="/projects" className="btn-pill btn-pill-secondary">All Projects</Link>
          </Reveal>
        </div>

        <div className="container-q grid gap-20 md:gap-28">
          {work.map((w, i) => (
            <Reveal key={w.title} delay={i * 80}>
              <article className="grid md:grid-cols-12 gap-8 md:gap-12 items-end">
                <div className="md:col-span-7">
                  <div className="aspect-[16/10] bg-[color:var(--muted)] relative overflow-hidden">
                    <div className="absolute inset-0 [background:radial-gradient(120%_80%_at_30%_20%,rgba(255,107,0,0.18),transparent_60%),radial-gradient(80%_60%_at_80%_80%,rgba(255,255,255,0.06),transparent_70%)]" />
                    <div className="absolute inset-0 [background-image:radial-gradient(rgba(255,255,255,0.06)_1px,transparent_1px)] [background-size:18px_18px]" />
                    <span className="absolute bottom-5 left-5 font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                      Case Study / 0{i + 1}
                    </span>
                  </div>
                </div>
                <div className="md:col-span-5 space-y-5">
                  <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-muted-foreground">{w.tag}</p>
                  <h3 className="font-display text-3xl md:text-4xl font-semibold leading-tight">{w.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{w.desc}</p>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="py-32 md:py-48">
        <div className="container-q">
          <Reveal>
            <PillTags filled="Recognition" outline="Placeholder · To be replaced" className="mb-10" />
          </Reveal>
          <Reveal>
            <h2 className="text-display-xl mb-16">What people say.</h2>
          </Reveal>
          <div className="grid gap-6 md:grid-cols-3">
            {testimonials.map((t, i) => (
              <Reveal key={i} delay={i * 100}>
                <article
                  style={{
                    background: "#111111",
                    border: "1px solid rgba(255,255,255,0.08)",
                    borderRadius: "var(--radius)",
                    padding: 36,
                    height: "100%",
                    display: "flex",
                    flexDirection: "column",
                  }}
                >
                  <div className="font-display" style={{ color: "#FF6B00", fontSize: 48, lineHeight: 1, marginBottom: 12 }}>
                    &ldquo;
                  </div>
                  <p style={{ color: "#fff", fontSize: 15, lineHeight: 1.7, flex: 1 }}>
                    {t.quote}
                  </p>
                  <div style={{ height: 1, background: "rgba(255,255,255,0.08)", margin: "24px 0 18px" }} />
                  <p className="font-mono" style={{ color: "#fff", fontSize: 12, letterSpacing: "0.08em", textTransform: "uppercase" }}>
                    {t.name}
                  </p>
                  <p style={{ color: "rgba(255,255,255,0.4)", fontSize: 12, marginTop: 4 }}>
                    {t.role}
                  </p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="py-40 md:py-64">
        <div className="container-q text-center">
          <Reveal>
            <PillTags filled="08" outline="The Standard" className="justify-center mb-12" />
          </Reveal>
          <h2 className="text-display-hero">
            <Reveal as="span" className="block">Build.</Reveal>
            <Reveal as="span" delay={120} className="block">Innovate.</Reveal>
            <Reveal as="span" delay={240} className="block">
              Evolve<span className="text-[color:var(--accent)]">.</span>
            </Reveal>
          </h2>
          <Reveal delay={420}>
            <div className="mt-16 flex justify-center">
              <Link to="/contact" className="btn-pill btn-pill-primary">Start a Conversation</Link>
            </div>
          </Reveal>
        </div>
      </section>
    </SiteLayout>
  );
}
