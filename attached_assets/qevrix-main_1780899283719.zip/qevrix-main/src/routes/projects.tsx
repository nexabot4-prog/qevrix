import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/Layout";
import { Reveal } from "@/components/site/Reveal";
import { PillTags } from "@/components/site/PillTags";

export const Route = createFileRoute("/projects")({
  head: () => ({
    meta: [
      { title: "Projects — QEVRIX" },
      { name: "description", content: "Selected engineering projects from QEVRIX across robotics, automation, embedded systems, AI and platforms." },
      { property: "og:title", content: "Projects — QEVRIX" },
      { property: "og:description", content: "Selected engineering projects from QEVRIX." },
    ],
  }),
  component: Projects,
});

const projects = [
  {
    index: "01",
    domain: "Robotics & Automation",
    year: "2026",
    title: "Autonomous Delivery Robot",
    summary: "A reusable autonomy layer combining perception, control and safety primitives for ground robotics.",
    body: "An intelligent autonomous delivery platform engineered for indoor logistics, route execution, RFID authentication, and real-time operational visibility. Built around modular robotics architecture, embedded control systems, wireless communication, and web-based management to create a scalable autonomous delivery ecosystem.",
    metrics: [
      { k: "Navigation Nodes", v: "50+" },
      { k: "Delivery Routes", v: "Dynamic" },
      { k: "Operation Modes", v: "Autonomous + Manual" },
    ],
  },
  {
    index: "02",
    domain: "EV & Energy Systems",
    year: "2026",
    title: "Smart EV Charging Platform",
    summary: "A connected charging infrastructure delivering secure access, intelligent power allocation, and real-time station management.",
    body: "A next-generation charging ecosystem combining wired and wireless charging infrastructure with intelligent monitoring, dynamic power management, and connected user experiences. Engineered to support future mobility systems through scalable energy delivery, real-time analytics, and seamless charging operations.",
    metrics: [
      { k: "Charging", v: "Wired + Wireless" },
      { k: "Control", v: "Smart Management" },
      { k: "Monitoring", v: "Real-Time" },
    ],
  },
  {
    index: "03",
    domain: "Cybersecurity & Embedded Systems",
    year: "2026",
    title: "Secure Smart Access System",
    summary: "A security-first access control architecture combining embedded systems, computer vision, and privacy-preserving authentication.",
    body: "A security-first architecture integrating embedded systems, intelligent authentication, computer vision, and privacy-preserving access control. Designed around secure identity verification, encrypted access workflows, and continuous monitoring to create trusted physical security environments.",
    metrics: [
      { k: "Authentication", v: "Multi-Layer" },
      { k: "Security", v: "Zero-Knowledge" },
      { k: "Access Logs", v: "Encrypted" },
    ],
  },
  {
    index: "04",
    domain: "AI Vision Systems",
    year: "2026",
    title: "VisionGuard",
    summary: "An AI-powered surveillance platform for intelligent monitoring, anomaly detection, and real-time visual analysis.",
    body: "An AI-powered smart glasses platform designed to improve independence and situational awareness for visually impaired individuals. Combining computer vision, object detection, voice assistance, and intelligent navigation, VisionGuard translates environmental information into actionable guidance in real time.",
    metrics: [
      { k: "Vision", v: "AI-Powered" },
      { k: "Guidance", v: "Real-Time" },
      { k: "Accessibility", v: "Enhanced" },
    ],
  },
];

function Projects() {
  return (
    <SiteLayout>
      {/* Header */}
      <section className="pt-40 md:pt-56 pb-24 md:pb-32">
        <div className="container-q">
          <Reveal>
            <PillTags filled="Projects" outline="Selected Work / 2025" className="mb-10" />
          </Reveal>
          <h1 className="text-display-hero max-w-[18ch]">
            <Reveal as="span" className="block">A small body</Reveal>
            <Reveal as="span" delay={120} className="block">of serious</Reveal>
            <Reveal as="span" delay={240} className="block">
              engineering<span className="text-[color:var(--accent)]">.</span>
            </Reveal>
          </h1>
          <Reveal delay={420}>
            <p className="mt-12 max-w-2xl text-lg text-muted-foreground leading-relaxed">
              Each project is treated like a product launch — designed for clarity, built for endurance, documented for the people who will inherit it.
            </p>
          </Reveal>
        </div>
      </section>

      {/* Case studies */}
      <div className="border-t border-border">
        {projects.map((p, i) => (
          <section key={p.index} className={`py-24 md:py-40 ${i !== 0 ? "border-t border-border" : ""}`}>
            <div className="container-q">
              <Reveal>
                <div className="flex items-center gap-6 mb-10">
                  <span className="font-mono text-xs uppercase tracking-[0.22em] text-[color:var(--accent)]">{p.index}</span>
                  <span className="h-px flex-1 bg-border" />
                  <span className="font-mono text-xs uppercase tracking-[0.22em] text-muted-foreground">{p.domain} · {p.year}</span>
                </div>
              </Reveal>

              <Reveal>
                <h2 className="text-display-xl max-w-4xl">{p.title}</h2>
              </Reveal>

              <Reveal delay={120}>
                <div className="mt-14 aspect-[16/9] md:aspect-[21/9] bg-[color:var(--muted)] relative overflow-hidden">
                  <div
                    className="absolute inset-0"
                    style={{
                      background:
                        i % 2 === 0
                          ? "radial-gradient(120% 80% at 30% 30%, rgba(255,107,0,0.22), transparent 60%), radial-gradient(80% 60% at 80% 80%, rgba(255,255,255,0.08), transparent 70%)"
                          : "radial-gradient(120% 80% at 75% 25%, rgba(255,255,255,0.10), transparent 60%), radial-gradient(80% 60% at 20% 80%, rgba(255,107,0,0.18), transparent 70%)",
                    }}
                  />
                  <div className="absolute inset-0 [background:linear-gradient(transparent_calc(100%_-_1px),rgba(255,255,255,0.04)_calc(100%_-_1px)),linear-gradient(90deg,transparent_calc(100%_-_1px),rgba(255,255,255,0.04)_calc(100%_-_1px))] [background-size:48px_48px]" />
                  <span className="absolute bottom-6 left-6 font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                    QEVRIX / {p.title}
                  </span>
                </div>
              </Reveal>

              <div className="mt-16 grid md:grid-cols-12 gap-10">
                <Reveal className="md:col-span-7">
                  <p className="text-display-lg text-foreground/90 mb-8">{p.summary}</p>
                  <p className="text-muted-foreground leading-relaxed text-base md:text-lg max-w-2xl">{p.body}</p>
                </Reveal>
                <Reveal delay={140} className="md:col-span-5 md:pt-2">
                  <dl className="border-t border-border">
                    {p.metrics.map((m) => (
                      <div key={m.k} className="flex items-baseline justify-between py-5 border-b border-border">
                        <dt className="font-mono text-[11px] uppercase tracking-[0.22em] text-muted-foreground">{m.k}</dt>
                        <dd className="font-display text-2xl md:text-3xl font-semibold">{m.v}</dd>
                      </div>
                    ))}
                  </dl>
                </Reveal>
              </div>
            </div>
          </section>
        ))}
      </div>

      {/* End note */}
      <section className="py-40 md:py-56 border-t border-border">
        <div className="container-q text-center max-w-3xl mx-auto">
          <Reveal>
            <p className="label-mono mb-10">Next</p>
          </Reveal>
          <Reveal delay={120}>
            <h2 className="text-display-xl">
              More systems are being built — quietly, and with the same standard.
            </h2>
          </Reveal>
          <Reveal delay={300}>
            <div className="mt-14 flex justify-center">
              <Link to="/contact" className="btn-pill btn-pill-primary">Work with QEVRIX</Link>
            </div>
          </Reveal>
        </div>
      </section>
    </SiteLayout>
  );
}