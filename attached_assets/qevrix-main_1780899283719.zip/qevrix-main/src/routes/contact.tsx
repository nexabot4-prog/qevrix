import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteLayout } from "@/components/site/Layout";
import { Reveal } from "@/components/site/Reveal";
import { PillTags } from "@/components/site/PillTags";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — QEVRIX" },
      { name: "description", content: "Get in touch with QEVRIX about engineering work, collaborations, or future projects." },
      { property: "og:title", content: "Contact — QEVRIX" },
      { property: "og:description", content: "Get in touch with QEVRIX." },
    ],
  }),
  component: Contact,
});

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block group">
      <span className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">{label}</span>
      <div className="mt-3 border-b border-border focus-within:border-foreground transition-colors">
        {children}
      </div>
    </label>
  );
}

function Contact() {
  const [sent, setSent] = useState(false);

  return (
    <SiteLayout>
      <section className="pt-40 md:pt-56 pb-24">
        <div className="container-q">
          <Reveal>
            <PillTags filled="QEVRIX" outline="Contact" className="mb-10" />
          </Reveal>
          <h1 className="text-display-hero max-w-[14ch]">
            <Reveal as="span" className="block">Start a</Reveal>
            <Reveal as="span" delay={120} className="block">
              conversation<span className="text-[color:var(--accent)]">.</span>
            </Reveal>
          </h1>
          <Reveal delay={300}>
            <p className="mt-12 max-w-xl text-lg text-muted-foreground leading-relaxed">
              For collaborations, engineering work, or to learn more about what we are building — write to us.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="py-24 md:py-32 border-t border-border">
        <div className="container-q grid md:grid-cols-12 gap-16">
          <Reveal className="md:col-span-4 space-y-12">
            <div>
              <p className="label-mono mb-4">Email</p>
              <a href="mailto:hello@qevrix.com" className="font-display text-2xl md:text-3xl font-semibold hover:text-[color:var(--accent)] transition-colors">
                hello@qevrix.com
              </a>
            </div>
            <div>
              <p className="label-mono mb-4">Hours</p>
              <p className="text-muted-foreground leading-relaxed">
                We respond within two working days.
              </p>
            </div>
            <div>
              <p className="label-mono mb-4">Location</p>
              <p className="text-muted-foreground leading-relaxed">
                Operating globally · Headquarters forthcoming
              </p>
            </div>
          </Reveal>

          <Reveal delay={160} className="md:col-span-8">
            {sent ? (
              <div className="border-t border-border pt-16">
                <p className="label-mono mb-6">Received</p>
                <h2 className="text-display-lg">
                  Thank you. We've received your message and will be in touch.
                </h2>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setSent(true);
                }}
                className="space-y-10"
              >
                <div className="grid md:grid-cols-2 gap-10">
                  <Field label="Name">
                    <input required type="text" name="name" className="w-full bg-transparent py-3 text-lg text-foreground placeholder:text-muted-foreground outline-none" placeholder="Your name" />
                  </Field>
                  <Field label="Email">
                    <input required type="email" name="email" className="w-full bg-transparent py-3 text-lg text-foreground placeholder:text-muted-foreground outline-none" placeholder="you@domain.com" />
                  </Field>
                </div>
                <Field label="Organisation (optional)">
                  <input type="text" name="org" className="w-full bg-transparent py-3 text-lg text-foreground placeholder:text-muted-foreground outline-none" placeholder="Company or institution" />
                </Field>
                <Field label="Message">
                  <textarea required name="message" rows={5} className="w-full bg-transparent py-3 text-lg text-foreground placeholder:text-muted-foreground outline-none resize-none" placeholder="Tell us what you are building or exploring." />
                </Field>

                <div className="pt-6">
                  <button type="submit" className="btn-pill btn-pill-primary">Send Message</button>
                </div>
              </form>
            )}
          </Reveal>
        </div>
      </section>
    </SiteLayout>
  );
}